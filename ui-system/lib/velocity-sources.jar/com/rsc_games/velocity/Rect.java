package com.rsc_games.velocity;

import com.rsc_games.velocity.Rect;
import com.rsc_games.velocity.util.Vector2;
import com.rsc_games.velocity.util.Warnings;

/**
 * Standard Velocity rectangle representation. Only allows integer coordinates and
 * values for size and position.
 */
public class Rect implements Cloneable {
    /**
     * This rectangle's top left X position (in pixels).
     */
    private float x;

    /**
     * This rectangle's top left Y position (in pixels).
     */
    private float y;

    /**
     * This rectangle's width (in pixels).
     */
    private float w;

    /**
     * This rectangle's height (in pixels).
     */
    private float h;

    /**
     * Externally visible X location (center location).
     * Externally, if the location of the object is requested, the center coordinates
     * will be given.
     */
    private float centerX;

    /**
     * Externally visibly Y location (center location).
     */
    private float centerY;

    /**
     * Create a rectangle at the center coordinates cx, cy with the
     * width and height w, h.
     * 
     * @param cx Center X location (in pixels).
     * @param cy Center Y location (in pixels).
     * @param w Width (in pixels).
     * @param h Height (in pixels).
     */
    public Rect(float cx, float cy, float w, float h) {
        this.w = w;
        this.h = h;
        this.setPos(new Vector2(cx, cy));
    }

    /**
     * Create a rectangle at the center coordinates p, with the width and
     * height w, h.
     * 
     * @param p Center position (in pixels).
     * @param w Width of rect (in pixels).
     * @param h Height of rect (in pixels).
     */
    public Rect(Vector2 p, float w, float h) {
        this.w = w;
        this.h = h;
        this.setPos(p);
    }

    /**
     * Create a rectangle at the center coordinates p, with the width and
     * height wh.
     * 
     * @param p Center position (in pixels).
     * @param wh Width and height (in pixels).
     */
    public Rect(Vector2 p, Vector2 wh) {
        this.w = wh.x;
        this.h = wh.y;
        this.setPos(p);
    }

    /**
     * @deprecated For Velocity Internal use only. Does not set the center x or y
     * locations. Only used for hard-setting the topleft position and width.
     * 
     * @param pos Array of values for setting.
     * @param suppressWarning Velocity will automatically warn when this constructor is
     *  used. Prevent that.
     */
    @Deprecated(forRemoval=false, since="v0.4.0.1")
    public Rect(float[] pos, boolean suppressWarning) {
        if (!suppressWarning)
            Warnings.warn("velocity.Rect", 
                "Rect(float[], boolean) doesn't set all required values!");
        this.x = pos[0];
        this.y = pos[1];
        this.w = pos[2];
        this.h = pos[3];
        this.centerX = 0;
        this.centerY = 0;
    }

    /**
     * Set the rectangle's width and height.
     * 
     * @param w Rectangle width.
     * @param h Rectangle height.
     */
    public void setWH(float w, float h) {
        this.w = w;
        this.h = h;
        this.setPos(new Vector2(centerX, centerY));
    }

    /**
     * Set the rectangle's width and height.
     * 
     * @param wh Width and Height of the rectangle.
     */
    public void setWH(Vector2 wh) {
        this.w = wh.x;
        this.h = wh.y;
        this.setPos(new Vector2(centerX, centerY));
    }

    /**
     * Get this rectangle's width.
     * 
     * @return Width.
     */
    public float getW() {
        return this.w;
    }

    /**
     * Get this rectangle's height.
     * 
     * @return Height.
     */
    public float getH() {
        return this.h;
    }
    
    /**
     * Get this rectangle's size.
     * 
     * @return The rectangle width and height.
     */
    public Vector2 getSize() {
        return new Vector2(this.w, this.h);
    }

    /**
     * Move this rect a given distance.
     * 
     * @param p Move distance.
     */
    public void translate(Vector2 v) {
        this.setPos(this.getPos().add(v));
    }
    
    /**
     * Replaces {@code getPixelPos()}. Provides the top left point of this
     * rect. Commonly required for drawing, hence the name {@code getDrawLoc()}.
     * 
     * @return This rect's top left corner location.
     * TODO: misnomer
     */
    public Vector2 getDrawLoc() {
        return new Vector2(this.x, this.y);
    }

    /**
     * Get the current center location of this rectangle.
     * 
     * @return Center location (in pixels).
     */
    public Vector2 getPos() {
        return new Vector2(this.centerX, this.centerY);
    }

    /**
     * Set the current center location of this rect.
     * Automatically regenerates inner values as needed.
     * 
     * @param p New center.
     */
    public void setPos(Vector2 p) {
        this.centerX = p.x;
        this.centerY = p.y;

        // Maybe round later for slightly higher precision?
        this.x = this.centerX - (this.w / 2);
        this.y = this.centerY - (this.h / 2);
    }

    /**
     * Duplicate this rect.
     * 
     * @return A copied version of this rect.
     */
    public Rect clone() {
        return new Rect(this.centerX, this.centerY, this.w, this.h);
    }

    /**
     * Collision detection. Detects any overlap on this rect and another
     * passed-in rect.
     * 
     * @param other Other rect to collide with.
     * @return If they overlap.
     */
    public boolean overlaps(Rect other) {
        float tr = this.x + this.w;
        float tl = this.x;
        float tt = this.y;
        float tb = this.y + this.h;

        float or = other.x + other.w;
        float ol = other.x;
        float ot = other.y;
        float ob = other.y + other.h;
        
        /*
        (RectA.Left < RectB.Right 
        && RectA.Right > RectB.Left &&
         RectA.Top > RectB.Bottom && 
         RectA.Bottom < RectB.Top )
        */

        return (tl < or  // This right edge is less than the left edge of the other collider.
            && tr > ol // This left edge is greater than the right edge of the other.
            && (tt < ob // The top is lower than the bottom of the other.
            && tb > ot) // The bottom is higher than the top.
        );
    }
    
    /**
     * Print this rect's internal information out for debug purposes.
     * 
     * @return This representation.
     */
    public String toString() {
        return "(" + x + ", " + y + ", " + w + ", " + h + ") (cx: " + centerX + ", cy: " + centerY + ")";
    }
}
