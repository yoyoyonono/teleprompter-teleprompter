package com.rsc_games.velocity.util;

import com.rsc_games.velocity.Rect;

/**
 * Represents a transformation in Velocity.
 */
public class Transform implements Cloneable {
    /**
     * Current object location.
     */
    public Rect location;

    /**
     * Current object rotation.
     */
    public float rotation;

    /**
     * Current object scale.
     */
    public Vector2 scale;

    /**
     * Z layer of the current object.
     */
    public int sortOrder;
    
    /**
     * Create a new transformation representation for a sprite.
     * 
     * @param location Current location.
     * @param rotation Current rotation.
     * @param scale Current scale.
     * @param sortOrder Z sorting layer.
     */
    public Transform(Rect location, float rotation, Vector2 scale, int sortOrder) {
        this.location = location;
        this.rotation = rotation;
        this.scale = scale;
        this.sortOrder = sortOrder;
    }

    /**
     * Create a new transformation representation for a sprite.
     * 
     * @param location Current location (as a point).
     * @param rotation Current rotation.
     * @param scale Current scale.
     * @param sortOrder Z sorting layer.
     */
    public Transform(Vector2 location, float rotation, Vector2 scale, int sortOrder) {
        this.location = new Rect(location.clone(), Vector2.zero.clone());
        this.rotation = rotation;
        this.scale = scale.clone();
        this.sortOrder = sortOrder;
    } 

    /**
     * Create a new transformation representation for a sprite.
     * Defaults to 0 degrees rotation, 1x scale, and Z layer 0.
     * 
     * @param location Sprite rect.
     */
    public Transform(Rect location) {
        this(location.clone(), 0f, Vector2.one.clone(), 0);
    }

    /**
     * Create a new transformation representation for a sprite.
     * Defaults to 0 degrees rotation, 1x scale, and Z layer 0.
     * 
     * @param location Sprite center position.
     */
    public Transform(Vector2 location) {
        this(new Rect(location.clone(), Vector2.zero.clone()), 0f, Vector2.one.clone(), 0);
    }

    /**
     * Identity transformation..
     * Defaults to Point.zero 0 degrees rotation, 1x scale, and Z layer 0.
     * 
     */
    public Transform() {
        this(Vector2.zero.clone());
    }

    /**
     * Create a new transformation representation for a sprite.
     * Defaults to 1x scale and Z layer 0.
     * 
     * @param location Sprite rect.
     * @param rotation Current rotation.
     */
    public Transform(Rect location, float rotation) {
        this(location.clone(), rotation, Vector2.one.clone(), 0);
    }

    /**
     * Create a new transformation representation for a sprite.
     * Defaults to 0 degrees rotation and Z layer 0.
     * 
     * @param location Sprite rect.
     * @param scale Sprite scaling.
     */
    public Transform(Rect location, Vector2 scale) {
        this(location.clone(), 0f, scale.clone(), 0);
    }

    /**
     * Create a new transformation representation for a sprite.
     * Defaults to 0 degrees rotation and 1x scale.
     * 
     * @param location Sprite rect.
     * @param sortOrder Sprite rendering order.
     */
    public Transform(Rect location, int sortOrder) {
        this(location.clone(), 0f, Vector2.one.clone(), sortOrder);
    }

    /**
     * Create a new transformation representation for a sprite.
     * Defaults to Z layer 0.
     * 
     * @param location Sprite rect.
     * @param rotation Sprite Z rotation.
     * @param scale Sprite scaling.
     */
    public Transform(Rect location, float rotation, Vector2 scale) {
        this(location.clone(), rotation, scale.clone(), 0);
    }

    /**
     * Update the width and height of the internal rect.
     * 
     * @param bounds The new width and height.
     */
    public void updateRect(Vector2 bounds) {
        this.location.setWH(bounds);
    }

    /**
     * Set the center position of this transform.
     * 
     * @param position New center position.
     */
    public void setPosition(Vector2 position) {
        this.location.setPos(position);
    }

    /**
     * Get this transform's center location.
     * 
     * @return Current center location.
     */
    public Vector2 getPosition() {
        return this.location.getPos();
    }

    /**
     * Translate this transform.
     * 
     * @param delta Distance to move.
     */
    public void translate(Vector2 delta) {
        this.location.translate(delta);
    }

    /**
     * Rotate this transform.
     * 
     * @param delta Angle to rotate.
     */
    public void rotate(float delta) {
        this.rotation += delta;
    }

    /**
     * Rotate this transform.
     * 
     * @param angle Angle to rotate.
     */
    public void setRotation(float angle) {
        this.rotation = angle;
    }

    /**
     * Set this transform's scale.
     * 
     * @param scale New absolute scale.
     */
    public void setScale(Vector2 scale) {
        this.scale = scale.clone();
    }

    /**
     * Set the sorting layer of this transform.
     * 
     * @param zOrder sorting layer.
     */
    public void setZOrder(int zOrder) {
        this.sortOrder = zOrder;
    }

    /**
     * Create an independent copy of this transform.
     */
    @Override
    public Transform clone() {
        return new Transform(location.clone(), rotation, scale.clone(), sortOrder);
    }
}
