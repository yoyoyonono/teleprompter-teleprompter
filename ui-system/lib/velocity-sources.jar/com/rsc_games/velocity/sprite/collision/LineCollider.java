package com.rsc_games.velocity.sprite.collision;

import com.rsc_games.velocity.Line;
import com.rsc_games.velocity.renderer.DrawInfo;
import com.rsc_games.velocity.renderer.FrameBuffer;
import com.rsc_games.velocity.sprite.Sprite;
import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.util.Vector2;

import java.awt.Color;

/**
 * A collidable, represented as a single 1 pixel wide line. Usable at any
 * angle.
 */
public class LineCollider extends Sprite implements Collidable { // Sprite
    /**
     * The internal line representation.
     */
    public final Line l;

    /**
     * Create a line collider.
     * 
     * @param vec Starting position of the line.
     * @param rot Rotation angle (ignored)
     * @param name Sprite name.
     * @param end Ending position of the line.
     */
    public LineCollider(Vector2 vec, String name, Vector2 end) {
        super(new Transform(vec, 0, Vector2.zero, 0), name);
        this.l = new Line(vec, end);
    }

    /**
     * Draw this line collider on the debug renderer (with a red box).
     * 
     * @param fb The framebuffer to draw on.
     * @param d The draw transform.
     */
    @Override
    public void DEBUG_render(FrameBuffer fb, DrawInfo d) {
        Vector2 vec = d.drawRect.getDrawLoc();
        Vector2 start = this.l.getStart();
        Vector2 end = this.l.getEnd();
        Vector2 cpos = start.sub(d.drawRect.getDrawLoc());
        fb.drawLine(vec, end.sub(cpos), 1, new Color(255, 0, 0));
    }
}
