package com.rsc_games.velocity.sprite.camera;

import com.rsc_games.velocity.sprite.Camera;
import com.rsc_games.velocity.sprite.Sprite;
import com.rsc_games.velocity.util.Logger;
import com.rsc_games.velocity.util.Vector2;

/**
 * A basic 2D Camera. Extends the current Camera system and allows tracking a
 * target.
 */
public class Base2DCamera extends Camera {
    /**
     * The target to track.
     */
    private Sprite target;

    /**
     * Damping coefficient. Normally takes 20 frames to approach the target
     * transform.
     */
    private int smoothDiv = 20;

    /**
     * Create a new camera at a given position.
     * 
     * @param pos Position for the camera.
     */
    public Base2DCamera(Vector2 pos) {
        super(pos);
        Logger.warn("velocity.camera.Base2DCamera", "Warning: No framing target set!");
    }

    /**
     * Create a new camera at a given position following a provided tranform
     * target.
     * 
     * @param pos The camera starting location.
     * @param target The camera tracking target.
     */
    public Base2DCamera(Vector2 pos, Sprite target) {
        super(pos);
        this.target = target;
    }

    /**
     * Change the current framing target. When there is no target then one can
     * be set.
     * 
     * @param s
     */
    public void setFramingTarget(Sprite s) {
        this.target = s;
    }

    /**
     * Change the damping coefficient. Useful for potentially changing effects
     * or follow speeds.
     * 
     * @param smoothDiv The smoothing coefficient.
     */
    public void setSmoothDiv(int smoothDiv) {
        this.smoothDiv = smoothDiv;
    }

    /**
     * Camera tick. Follow a framing target, if one is set.
     */
    protected void onTick() {
        super.onTick();
        if (this.target == null) return;

        Vector2 target_center = target.transform.getPosition();
        Vector2 this_center = this.transform.getPosition();
        Vector2 distance = this_center.vectorDistTo(target_center);
        this.transform.translate(distance.div(smoothDiv));

        //float oRot = this.rot;
        //this.rot += (player.rot - this.rot) / (smoothDiv / 2);
    }
}
