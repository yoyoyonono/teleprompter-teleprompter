package com.rsc_games.velocity.sprite.camera;

import java.awt.event.KeyEvent;

import com.rsc_games.velocity.InputSystem;

import com.rsc_games.velocity.sprite.Camera;
import com.rsc_games.velocity.util.Vector2;

public class DebugFreeLookCamera extends Camera {
    /**
     * Create a new camera at a given position following a provided tranform
     * target.
     * 
     * @param pos The camera starting location.
     */
    public DebugFreeLookCamera(Vector2 pos) {
        super(pos);
    }

    /**
     * Camera tick. Allow panning.
     */
    protected void onTick() {
        super.onTick();
        
        Vector2 mvec = new Vector2(
            InputSystem.getAxis(KeyEvent.VK_RIGHT, KeyEvent.VK_LEFT) * 10,
            -InputSystem.getAxis(KeyEvent.VK_UP, KeyEvent.VK_DOWN) * 10
        );

        this.transform.translate(mvec);
    }
}
