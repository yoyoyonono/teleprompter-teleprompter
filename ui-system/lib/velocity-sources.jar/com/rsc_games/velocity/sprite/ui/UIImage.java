package com.rsc_games.velocity.sprite.ui;

import com.rsc_games.velocity.renderer.DrawInfo;
import com.rsc_games.velocity.renderer.FrameBuffer;
import com.rsc_games.velocity.renderer.RendererImage;
import com.rsc_games.velocity.system.ImageLoader;
import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.util.Vector2;

/**
 * Basic image rendered on a UI panel.
 */
public abstract class UIImage extends UIRenderable {
    /**
     * The image to render.
     */
    public RendererImage img;

    /**
     * Create a UIImage.
     * 
     * @param anchor UI element screen anchoring.
     * @param transform Screen space UI element transform.
     * @param name The name of the sprite.
     * @param imagename The image filepath.
     */
    public UIImage(AnchorPoint anchor, Transform transform, String name, String imagename) {
        super(anchor, transform, name);
        this.img = ImageLoader.loadImage(imagename);
        this.transform.updateRect(new Vector2(img.getWidth(), img.getHeight()));
    }

    /**
     * Create a UIImage, and directly provide an image.
     * 
     * @param pos The offset transform for the image.
     * @param rot The image rotation angle.
     * @param name The name of the sprite.
     * @param imageHnd The image reference.
     */
    public UIImage(AnchorPoint anchor, Transform transform, String name, RendererImage imageHnd) {
        super(anchor, transform, name);
        this.img = imageHnd;
        this.transform.updateRect(new Vector2(img.getWidth(), img.getHeight()));
    }

    /**
     * Draw the image on screen.
     * 
     * @param d Draw transform.
     * @param fb Rendering framebuffer.
     */
    @Override
    public void renderUI(DrawInfo d, FrameBuffer fb) {
        fb.blit(this.img, d);
    }
}
