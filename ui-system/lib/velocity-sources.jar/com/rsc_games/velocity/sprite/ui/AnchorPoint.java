package com.rsc_games.velocity.sprite.ui;

import com.rsc_games.velocity.sprite.Camera;
import com.rsc_games.velocity.util.Point;
import com.rsc_games.velocity.util.Vector2;

/**
 * Anchor points for UI and HUD rendering.
 */
public class AnchorPoint {
    public static final AnchorPoint TOP_LEFT = new AnchorPoint("topleft");
    public static final AnchorPoint TOP_RIGHT = new AnchorPoint("topright");
    public static final AnchorPoint TOP_MID = new AnchorPoint("top");
    public static final AnchorPoint RIGHT = new AnchorPoint("right");
    public static final AnchorPoint LEFT = new AnchorPoint("left");
    public static final AnchorPoint CENTER = new AnchorPoint("center");
    public static final AnchorPoint LOWER_LEFT = new AnchorPoint("bottomleft");
    public static final AnchorPoint LOWER_RIGHT = new AnchorPoint("bottomright");
    public static final AnchorPoint BOTTOM = new AnchorPoint("bottom");

    private final String anchor;

    private AnchorPoint(String anchor) {
        this.anchor = anchor;
    }

    /**
     * Calculate a base offset to transform an image from. The offset will change
     * whenever the screen is rescaled, so call this regularly.
     * 
     * @param loc A location on the UI canvas to anchor to.
     *   Can be one of the following values.
     *   "topleft": Anchor to the top left of the screen. Really not needed, since
     *      its the default.
     *   "top": Anchor to the top of the screen in the center on the x axis.
     *   "topright": Anchor to the top right corner of the screen.
     *   "right": Anchor to the right side of the screen in the center on the y axis.
     *   "left": Anchor to the left side of the screen in the center on the y axis.
     *   "bottomleft": Anchor to the bottom left corner of the screen.
     *   "bottom": Anchor to the bottom of the screen in the center on the x axis.
     *   "bottomright": Anchor to the bottom right corner of the screen.
     *   "center": Anchor to the center of the screen on both axis.
     * @return the actual anchor point in screen space.
     */
    public Vector2 getAnchor() {
        Point cres = Camera.res;

        switch (this.anchor) {
            case "topleft":
                return Vector2.zero.clone();
            case "top":
                return new Vector2(cres.x / 2, 0);
            case "topright":
                return new Vector2(cres.x, 0);
            case "right":
                return new Vector2(cres.x, cres.y / 2);
            case "left":
                return new Vector2(0, cres.y / 2);
            case "bottomleft":
                return new Vector2(0, cres.y);
            case "bottom":
                return new Vector2(cres.x / 2, cres.y);
            case "bottomright":
                return new Vector2(cres);
            case "center":
                return new Vector2(cres).div(2);
            default:
                // Really REALLY should not be possible without weird runes (aka reflection)
                throw new IllegalArgumentException("Invalid anchor point specified: " + anchor);
        }
    }
}
