package com.rsc_games.velocity.sprite.ui;

import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.Rect;
import com.rsc_games.velocity.renderer.DrawInfo;
import com.rsc_games.velocity.renderer.FrameBuffer;
import com.rsc_games.velocity.sprite.Sprite;

/**
 * A generic renderable that can be drawn on a UI Canvas.
 */
public abstract class UIRenderable extends Sprite {
    /**
     * Screen area where this renderable anchors itself to. Replaces all of the nasty
     * logic provided in subclasses.
     */
    AnchorPoint anchor;

    /**
     * Create a UI Renderable object.
     * 
     * @param pos The renderable position.
     * @param rot The renderable rotation angle.
     * @param name The renderable's name.
     */
    public UIRenderable(AnchorPoint anchor, Transform transform, String name) {
        super(transform, name);
    }

    /**
     * Get the location of this renderable in screenspace at this time.
     * Since the output resolution may change, the output of this function
     * will vary frame by frame and should not be cached.
     * 
     * @return Location of this UI element in screen space.
     */
    public Rect getScreenSpaceRect() {
        Rect ssRect = this.transform.location.clone();
        ssRect.translate(anchor.getAnchor());
        return ssRect;
    }

    /**
     * Render this renderable on the UI panel during the UI compositing stage.
     * 
     * @param d Draw transforms.
     * @param fb Rendering framebuffer.
     */
    public abstract void renderUI(DrawInfo d, FrameBuffer fb);
}
