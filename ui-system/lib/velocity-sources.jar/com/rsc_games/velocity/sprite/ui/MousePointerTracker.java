package com.rsc_games.velocity.sprite.ui;

import java.awt.Color;

import com.rsc_games.velocity.InputSystem;
import com.rsc_games.velocity.Scene;

import com.rsc_games.velocity.renderer.DrawInfo;
import com.rsc_games.velocity.renderer.FrameBuffer;
import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.util.Vector2;

/**
 * Prints the current screen space mouse coordinates for easier debugging.
 * Part of the modern replacement for the ancient DebugRenderer system.
 */
// TODO: Add autoinjection of this when using the debug renderer config.
// TODO: Don't simulate tick of objects while running the debug renderer.
// TODO: Render collision geometry and stuff.
public class MousePointerTracker extends UIText {
    /**
     * Mouse pointer tracker.
     * 
     * @param anchor Screen anchor.
     * @param transform Screen space transform of the object.
     * @param name The name of the sprite.
     * @param c The text color.
     */
    public MousePointerTracker(AnchorPoint anchor, Transform transform, String name, Color c) {
        super(anchor, transform, name, "Serif", c);
        this.transform.sortOrder = 1;
        this.color = c;
    }

    /**
     * Draw during the UI compositing stage.
     * Counter values updated during this stage.
     * 
     * @param d Draw info.
     * @param fb Rendering framebuffer.
     */
    @Override
    public void renderUI(DrawInfo d, FrameBuffer fb) {    
        String text = "mouse_world_coords: " 
            + Scene.currentScene.screenToWorldPoint(InputSystem.getMousePos());

        Vector2 coords = d.drawRect.getDrawLoc();
        fb.drawText(coords, text, this.font, this.color);
    }
}
