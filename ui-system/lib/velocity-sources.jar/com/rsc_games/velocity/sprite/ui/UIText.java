package com.rsc_games.velocity.sprite.ui;

import java.awt.Color;
import java.awt.Font;

import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.util.Vector2;
import com.rsc_games.velocity.renderer.DrawInfo;
import com.rsc_games.velocity.renderer.FrameBuffer;

/**
 * Basic text renderer for the UI Canvas.
 */
public class UIText extends UIRenderable {
    /**
     * Text color. Defaults to red text.
     */
    Color color = Color.red;

    /**
     * Text size (in pixels).
     */
    protected int size;

    /**
     * The current font for rendering.
     */
    protected Font font;

    /**
     * String to render.
     */
    protected String text;

    /**
     * Create the UI Text renderable.
     * 
     * @param anchor UI element anchoring.
     * @param transform UI element transform.
     * @param name The sprite name.
     * @param fontPath The path of the font file.
     * @param c The text color 
     */
    public UIText(AnchorPoint anchor, Transform transform, String name, String fontPath, Color c) {
        super(anchor, transform, name);
        this.color = c;
        this.size = 12;
        this.font = new Font(fontPath, Font.PLAIN, size);
        this.text = "";
    }

    /**
     * Set the rendered text size.
     * 
     * @param size New text size.
     */
    public void setSize(int size) {
        this.size = size;
        this.font = this.font.deriveFont(Font.PLAIN, (float) size);
    }

    /**
     * Render the text in the compositing stage.
     * 
     * @param d Draw transform.
     * @param fb Rendering frame buffer.
     */
    @Override
    public void renderUI(DrawInfo d, FrameBuffer fb) {
        Vector2 coords = d.drawRect.getDrawLoc();
        fb.drawText(coords, this.text, this.font, this.color);
    }
}
