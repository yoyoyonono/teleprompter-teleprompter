package com.rsc_games.velocity.sprite;

import com.rsc_games.velocity.sprite.Camera;
import com.rsc_games.velocity.util.Point;
import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.util.Vector2;

/**
 * The base camera implementation of Velocity. Essential for rendering.
 */
public class Camera extends Sprite {
    /**
     * Current window resolution. One of the most important lines of code in
     * the entirety of Velocity (and importance being determined by usage).
     */
    // TODO: Inflexible and not containerized. Should talk to the renderer for this information.
    // TODO: frame_delta is a useful metric to know (should be added to the renderer)
    // We could just pass it into tick as a parameter?
    @Deprecated(forRemoval=true)
    public static Point res = new Point(1, 1);

    /**
     * Create a standard camera.
     * 
     * @param vec Camera starting position.
     */
    public Camera(Vector2 vec) {
        super(new Transform(vec, 0f, Vector2.one, 0), "Main Camera");
        this.transform.updateRect(new Vector2(Camera.res));
    }

    /**
     * Update the local camera resolution when the screen resolution changes.
     */
    protected void onTick() {
        // BUGFIX (Velocity v0.1.0.0): Workaround for bad camera scaling.
        this.transform.updateRect(new Vector2(Camera.res));
    }
}
