package com.rsc_games.velocity.sprite;

import com.rsc_games.velocity.util.Transform;
import com.rsc_games.velocity.renderer.DrawInfo;
import com.rsc_games.velocity.renderer.FrameBuffer;
import com.rsc_games.velocity.renderer.RendererImage;

/**
 * A basic sprite with an image that can be drawn on-screen and responds
 * to illumination.
 */
public class LitSprite extends ImageSprite {

    /**
     * Create a lit sprite.
     * 
     * @param transform The center position of the sprite.
     * @param name The name of the sprite.
     * @param image The image path.
     */
    public LitSprite(Transform transform, String name, String image) {
        super(transform, name, image);
    }

    /**
     * Alternate constructor. Allows passing in a loaded image instead of
     * a file path.
     * 
     * @param pos The center position.
     * @param rot The rotation angle.
     * @param name The name of the sprite.
     * @param image The image reference.
     */
    public LitSprite(Transform transform, String name, RendererImage image) {
        super(transform, name, image);
    }

    /**
     * Draw the image on screen.
     * 
     * @param d Draw transform
     * @param fb Rendering framebuffer.
     */
    @Override
    public void render(DrawInfo d, FrameBuffer fb) {
        fb.drawShaded(this.img, d);
    }

    /**
     * Draw the image on the debug renderer.
     * 
     * @param fb Rendering framebuffer.
     * @param info Draw transform
     */
    @Override
    public void DEBUG_render(FrameBuffer fb, DrawInfo info) {
        //fb.blit(this.img, info);
    }
}
