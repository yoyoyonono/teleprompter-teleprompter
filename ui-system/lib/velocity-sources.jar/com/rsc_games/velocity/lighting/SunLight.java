package com.rsc_games.velocity.lighting;

import java.awt.Color;

import com.rsc_games.velocity.util.Vector2;

/**
 * Global light source abstraction. Represents an overhead light generally.
 */
public class SunLight extends LightSource {
    /**
     * Create a new SunLight.
     * 
     * @param intensity Light intensity.
     */
    public SunLight(float intensity) {
        this(intensity, Color.white);
    }

    /**
     * Create a sunlight and specify its color.
     * 
     * @param intensity Light intensity.
     * @param color The color of the light.
     */
    public SunLight(float intensity, Color color) {
        super();
        this.lightid = this.le.newSunLight(intensity, color);
    }

    /**
     * Set the light intensity.
     * 
     * @param intensity New light intensity.
     */
    public void setIntensity(float intensity) {
        this.getSource().setIntensity(intensity);
    }

    /**
     * Get the internal light source from the lighting engine.
     * 
     * @return The internal light source.
     */
    private InternalLightSource getSource() {
        return this.le.getLightSourceFromID(this.lightid);
    }
    
    /**
     * Stubbed function. Unsupported operation.
     */
    // TODO: Remnant of bad abstraction.
    public void setPos(Vector2 v) {}
}
