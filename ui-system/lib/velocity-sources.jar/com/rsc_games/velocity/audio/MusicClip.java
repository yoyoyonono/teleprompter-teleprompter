package com.rsc_games.velocity.audio;

import static org.lwjgl.openal.AL10.AL_BUFFERS_PROCESSED;
import static org.lwjgl.openal.AL10.alBufferData;
import static org.lwjgl.openal.AL10.alGetSourcei;
import static org.lwjgl.openal.AL10.alSourcePause;
import static org.lwjgl.openal.AL10.alSourcePlay;
import static org.lwjgl.openal.AL10.alSourceQueueBuffers;
import static org.lwjgl.openal.AL10.alSourceStop;
import static org.lwjgl.openal.AL10.alSourceUnqueueBuffers;

import java.io.IOException;
import java.nio.ByteBuffer;

public class MusicClip {
    private static final int BUFFER_SIZE = 8192;

    AudioEngine engine;
    WaveDecoder wav;

    int loopIndex;
    int format;

    int[] buffers = new int[3];
    int source;
    ByteBuffer tempBuffer;

    boolean keepPlaying = true;
    boolean loop;

    /**
     * 
     * @param path
     * @param loop
     * @param loopPoint
     */
    public MusicClip(String path, boolean loop, float loopPoint) {
        this.engine = AudioEngine.theEngine;
        this.loop = loop;

        try {
            this.wav = new WaveDecoder(path);
            this.format = this.wav.getSampleFormat();
            this.loopIndex = Math.round(this.wav.frameWidth * this.wav.frameRate * loopPoint); 

            this.tempBuffer = ByteBuffer.allocateDirect(BUFFER_SIZE);
            this.source = this.engine.genSource();

            for (int i = 0; i < buffers.length; i++) {
                buffers[i] = this.engine.genBuffer();

                tempBuffer.position(0);
                this.wav.readInto(tempBuffer);
                alBufferData(buffers[i], this.format, tempBuffer, this.wav.frameRate);
            }
        }
        catch (IOException ie) {
            throw new RuntimeException("unable to find audio file " + path);
        }
    }

    void refillBuffer(int bufferID) {
        this.tempBuffer.position(0);
        
        try {
            int remaining = this.wav.readInto(tempBuffer);

            if (remaining < BUFFER_SIZE) {
                if (loop) {
                    this.wav.seek(this.loopIndex);
                    remaining += this.wav.readInto(tempBuffer);

                    if (remaining != BUFFER_SIZE)
                        throw new RuntimeException("buffer read mismatch");
                }
                else
                    keepPlaying = false;
            }
            
            alBufferData(bufferID, this.format, tempBuffer, this.wav.frameRate);
        }
        catch (IOException ie) {
            // piss off
        }
    }

    void tickRefillBuffers() {
        if (!keepPlaying)
            return;

        int processedBuffers = alGetSourcei(source, AL_BUFFERS_PROCESSED);

        if (processedBuffers == 0) 
            return;

        while (processedBuffers-- > 0) {
            int bufferID = alSourceUnqueueBuffers(source);
            this.refillBuffer(bufferID);
            alSourceQueueBuffers(source, bufferID);
        }
    }

    public void play() {
        alSourcePlay(source);
    }

    public void stop() {
        alSourceStop(source);
    }

    public void pause() {
        alSourcePause(source);
    }

    @Override 
    protected void finalize() throws Throwable {
        super.finalize();

        this.stop();
        this.engine.delSource(source);

        for (int i = 0; i < buffers.length; i++)
            this.engine.delBuffer(buffers[i]);
    }
}
