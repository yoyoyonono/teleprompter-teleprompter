package com.rsc_games.velocity.audio;

import static org.lwjgl.openal.AL10.alDeleteBuffers;
import static org.lwjgl.openal.AL10.alDeleteSources;
import static org.lwjgl.openal.AL10.alGenBuffers;
import static org.lwjgl.openal.AL10.alGenSources;
import static org.lwjgl.openal.ALC10.*;

import java.util.HashMap;

import org.lwjgl.openal.AL;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.ALCCapabilities;

import com.rsc_games.velocity.util.Logger;

/**
 * AudioEngine
 * 
 * Replacement audio mixer and engine for the default javax sampled engine.
 * Javax.sampled has a severe deficit of useful features and has terrible
 * memory usage to make things better. This engine uses OpenAL internally.
 */
public class AudioEngine {
    private static final int GC_MIN_THRESH = 8;

    static AudioEngine theEngine;
    private static long lastEngineID = 0;

    private HashMap<Long, SourceBuffer> idToBuffer = new HashMap<>();
    private HashMap<String, SourceBuffer> pathToBuffer = new HashMap<>();

    /**
     * OpenAL device.
     */
    private long alDev;

    /**
     * Active OpenAL context.
     */
    private long alCtx;

    /**
     * Number of entries above which to force a garbage collection. Depending on how consistently
     * high the watermark is the limit may be increased or decreased.
     */
    private int gcThreshold = GC_MIN_THRESH;

    public static void init() {
        if (theEngine != null)
            throw new IllegalStateException("Audio engine already initialized!");

        theEngine = new AudioEngine();
    }

    private AudioEngine() {
        this.alDev = alcOpenDevice((CharSequence)null);

        if (this.alDev == 0L) {
            Logger.error("audio.al", "No audio endpoint available?");
            throw new RuntimeException("Failed to open audio device.");
        }

        ALCCapabilities caps = ALC.createCapabilities(alDev);
        this.alCtx = alcCreateContext(alDev, (int[])null);
        alcMakeContextCurrent(this.alCtx);
        AL.createCapabilities(caps);
    }

    public static AudioEngine getEngine() {
        return theEngine;
    }

    /**
     * Clean out unreferenced source buffers and adjust watermarking for future GCs.
     * The whole point of this setup is to save memory not leak it.
     */
    public void runGarbageCollect() {
        int size = idToBuffer.size();
        int cleared = 0;

        for (long id : idToBuffer.keySet()) {
            SourceBuffer buffer = idToBuffer.get(id);

            if (buffer.hasReferences())
                continue;
            
            buffer.deallocate();
            pathToBuffer.values().remove(buffer);
            idToBuffer.values().remove(buffer);
            cleared++;
        }

        // adjust maximum size before gc triggers
        int watermark = size - cleared;

        // either high allocation/deallocation amounts or low total memory.
        // shrink allocation since we don't need it anymore
        if (watermark < size / 2)
            this.gcThreshold = Math.max(GC_MIN_THRESH, this.gcThreshold / 2);

        // high static memory; probably need more space anyway.
        else if (watermark > size * 0.75f)
            this.gcThreshold *= 1.5f;
    }

    /**
     * Get the corresponding preloaded source buffer for a song, if the song
     * has already been loaded into memory.
     * 
     * @param songPath Path to the song on disk.
     * @return The source buffer with the given path.
     */
    SourceBuffer getSourceBuffer(String songPath) {
        if (!pathToBuffer.containsKey(songPath)) {
            long engineID = lastEngineID++; 

            SourceBuffer buffer = new SourceBuffer(this, engineID, songPath);
            pathToBuffer.put(songPath, buffer);
            idToBuffer.put(engineID, buffer);

            if (idToBuffer.size() > gcThreshold)
                runGarbageCollect();

            return buffer;
        }

        return pathToBuffer.get(songPath);
    }

    /**
     * Get a preloade source buffer for a song. Assuming the song is already
     * loaded into memory, as it would have to be to receive an ID and nothing
     * external to this code could get one.
     * 
     * @param bufferID The desired buffer ID.
     * @return The desired buffer.
     */
    SourceBuffer bufferFromID(long bufferID) {
        return idToBuffer.get(bufferID);
    }

    // TODO: bgm inner class. only one permitted currently

    /**
     * Generate a buffer for a source to use.
     * 
     * @return A new buffer.
     */
    // TODO: we're leaking handles in the event of a forced engine reinit.
    // Should clean up later?
    int genBuffer() {
        return alGenBuffers();
    }

    /**
     * Delete a previously allocated buffer. 
     * 
     * @param bufferID Buffer to delete.
     */
    void delBuffer(int bufferID) {
        alDeleteBuffers(bufferID);
    }

    /**
     * Generate a single OpenAL source.
     * 
     * @return New source object.
     */
    int genSource() {
        return alGenSources();
    }

    /**
     * Delete an existing audio source.
     * 
     * @param sourceID The source to delete.
     */
    void delSource(int sourceID) {
        alDeleteSources(sourceID);
    }

    void deinit() {
        alcMakeContextCurrent(0L);
        alcDestroyContext(this.alCtx);
        alcCloseDevice(this.alDev);
    }
}
