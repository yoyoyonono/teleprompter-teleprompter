package com.rsc_games.velocity.audio;

// TODO: implement one day 10 years from now.
public class AudioListener {
    int listener;

    public AudioListener() { 
    }
}
