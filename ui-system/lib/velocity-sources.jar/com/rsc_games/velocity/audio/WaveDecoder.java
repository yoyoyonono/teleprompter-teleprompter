package com.rsc_games.velocity.audio;

import static org.lwjgl.openal.AL10.AL_FORMAT_MONO16;
import static org.lwjgl.openal.AL10.AL_FORMAT_MONO8;
import static org.lwjgl.openal.AL10.AL_FORMAT_STEREO16;
import static org.lwjgl.openal.AL10.AL_FORMAT_STEREO8;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import com.rsc_games.velocity.util.BytesFile;
import com.rsc_games.velocity.util.Logger;

/**
 * RIFF format
 *
 *   [Master RIFF chunk]
 *      FileTypeBlocID  (4 bytes) : Identifier « RIFF »  (0x52, 0x49, 0x46, 0x46)
 *      FileSize        (4 bytes) : Overall file size minus 8 bytes
 *      FileFormatID    (4 bytes) : Format = « WAVE »  (0x57, 0x41, 0x56, 0x45)
 *
 *  [Chunk describing the data format]
 *      FormatBlocID    (4 bytes) : Identifier « fmt_ »  (0x66, 0x6D, 0x74, 0x20)
 *      BlocSize        (4 bytes) : Chunk size minus 8 bytes, which is 16 bytes here  (0x10)
 *      AudioFormat     (2 bytes) : Audio format (1: PCM integer, 3: IEEE 754 float)
 *      NbrChannels     (2 bytes) : Number of channels
 *      Frequency       (4 bytes) : Sample rate (in hertz)
 *      BytePerSec      (4 bytes) : Number of bytes to read per second (Frequency * BytePerBloc).
 *      BytePerBloc     (2 bytes) : Number of bytes per block (NbrChannels * BitsPerSample / 8).
 *      BitsPerSample   (2 bytes) : Number of bits per sample
 *
 *  [Chunk containing the sampled data]
 *      DataBlocID      (4 bytes) : Identifier « data »  (0x64, 0x61, 0x74, 0x61)
 *      DataSize        (4 bytes) : SampledData size
 *      SampledData
 *  
 * WaveDecoder
 */
class WaveDecoder {
    private final static int FORMAT_PCM = 0x1;

    BytesFile wavFile;

    public final short channels;

    public final int frameRate;

    public final short frameWidth;

    public final int frameCount;

    RIFFChunk dataChunk;


    /**
     * Read a normally formatted WAV file. This class supports any and all PCM
     * encoded WAV files. Floating point is not supported as OpenAL likely doesn't
     * support it.
     * 
     * @param filePath Location of the wave file on disk.
     * @throws IOException because why not why shouldn't your life be difficult.
     */
    WaveDecoder(String filePath) throws IOException {
        this.wavFile = new BytesFile(filePath, "rb");

        RIFFHeader header = new RIFFHeader(wavFile);
        RIFFChunk[] chunks = enumerateChunks(header);

        RIFFChunk fmtChunk = findChunk(chunks, "fmt ");
        this.dataChunk = findChunk(chunks, "data");

        // format block parsing
        fmtChunk.seek(0);

        short format = fmtChunk.read(2).asShortBuffer().get();

        if (format != FORMAT_PCM)
            throw new IllegalArgumentException("unknown wave format " + format);

        this.channels = fmtChunk.read(2).asShortBuffer().get();
        this.frameRate = fmtChunk.read(4).asShortBuffer().get();
        fmtChunk.read(4 + 2); // skipping bytes per sec and bytes per block
        this.frameWidth = fmtChunk.read(2).asShortBuffer().get();
        this.frameCount = this.dataChunk.size / (this.frameWidth * this.channels);

        // set up playback
        this.dataChunk.seek(0);
    }

    /**
     * Determine the sample format of the input data.
     * 
     * @param wav Input wave file
     * @return Sample format.
     */
    int getSampleFormat() {
        int nChannels = this.channels;
        int nBytesPerSample = this.frameWidth / this.channels;

        if (nChannels == 1) {
            switch (nBytesPerSample) {
                case 1:
                    return AL_FORMAT_MONO8;
                case 2:
                    return AL_FORMAT_MONO16;
                default:
                    throw new RuntimeException("unsupported format: mono " + (nBytesPerSample * 8) + " bit");
            }
        } 
        else if (nChannels == 2) {
            switch (nBytesPerSample) {
                case 1:
                    return AL_FORMAT_STEREO8;
                case 2:
                    return AL_FORMAT_STEREO16;
                default:
                    throw new RuntimeException("unsupported format: stereo " + (nBytesPerSample * 8) + " bit");
            }
        }

        throw new RuntimeException("unsupported format: " + nChannels + " channel " + (nBytesPerSample * 8) + " bit");
    }

    /**
     * Get all RIFF chunks within this file (including their absolute file
     * offsets).
     * NOTE: This does not parse LIST chunks or any nested chunks.
     * 
     * @param header RIFF file header (with all unparsed chunks)
     * @return List of all enclosed chunks
     */
    private RIFFChunk[] enumerateChunks(RIFFHeader header) throws IOException {
        long eofOffset = header.dataOffset + header.size - 4;
        ArrayList<RIFFChunk> chunks = new ArrayList<>();

        while (this.wavFile.tell() < eofOffset) {
            RIFFChunk chunk = new RIFFChunk(this.wavFile, this.wavFile.tell());
            chunks.add(chunk);
            chunk.skipOver();
        }

        return chunks.toArray(RIFFChunk[]::new);
    }

    /**
     * Get a handle to a chunk that was previously enumerated.
     * 
     * @param chunks Pre-enumerated chunks list (pre-calculated offsets).
     * @param tag Tag of desired chunk
     * @return Desired chunk
     */
    private RIFFChunk findChunk(RIFFChunk[] chunks, String tag) {
        for (RIFFChunk chunk : chunks) {
            if (chunk.tag.equals(tag))
                return chunk;
        }

        throw new RuntimeException("missing chunk " + tag);
    }

    /**
     * Read numFrames frames from the chunk. Each frame is 1 set of samples,
     * so 2 samples for stereo and 1 for mono. Standard stereo audio would be
     * 4 bytes per frame (2 B left, 2 B right).
     * 
     * @param numFrames Number of frames to read.
     * @return Buffer with read frames
     */
    ByteBuffer read(int numFrames) throws IOException {
        return this.dataChunk.read(numFrames * frameWidth);
    }

    /**
     * Stream frames into the provided buffer. Buffer must be a multiple of the
     * frame width.
     * 
     * @param buf Buffer to read into.
     * @return Number of bytes read.
     * @throws IOException Because things like to explode and burn.
     */
    int readInto(ByteBuffer buf) throws IOException {
        if (buf.limit() % this.frameWidth != 0)
            throw new IndexOutOfBoundsException("bad buffer size");

        return this.dataChunk.readinto(buf);
    }

    /**
     * Seek within the data region of this file. 0 offset corresponds to frame
     * 0 at the beginning.
     * 
     * @param offset Offset within the sample region.
     */
    void seek(int offset) {
        this.dataChunk.seek(offset);
    }

    void close() {
        this.wavFile.close();
        this.dataChunk = null;
    }
}

/**
 * More RIFF parsing. RIFF headers this time around woohoo.
 * This is literally just a struct but unfortunately Java does not support
 * structs.
 * RIFFHeader
 */
class RIFFHeader {
    public final long size;
    public final long dataOffset;

    /**
     * NOTE: Not a compliant RIFF parser by design.
     *
     * All chunks have the following format:
     * 
     * 4 bytes: an ASCII identifier for this chunk (examples are "fmt " and "data"; note the space in "fmt ").
     * 4 bytes: an unsigned, little-endian 32-bit integer with the length of this chunk (except this field itself and the chunk identifier).
     *  variable-sized field: the chunk data itself, of the size given in the previous field.
     *  a pad byte, if the chunk's length is not even.
     * 
     * @param file Input file to parse
     */
    RIFFHeader(BytesFile file) throws IOException {
        file.seek(0);
        
        if (!StandardCharsets.UTF_8.decode(file.read(4)).toString().equals("RIFF"))
            throw new RuntimeException("bad riff header");

        this.size = file.read(4).asIntBuffer().get();

        if (!StandardCharsets.UTF_8.decode(file.read(4)).toString().equals("WAVE"))
            throw new RuntimeException("not wav file");

        this.dataOffset = file.tell();
    }
}

/**
 * This is by no means a fully compliant RIFF parser but it works well enough
 * to parse wave files and that's good enough for me.
 * RIFFChunk
 */
class RIFFChunk {
    /**
     * Enclosing file of this chunk. Shared with other chunks so
     * only read one at a time.
     */
    BytesFile file;

    /**
     * 4 character code (FourCC) tag for this chunk. 
     */
    String tag;

    /**
     * Size of the RIFF chunk in bytes.
     */
    int size;

    /**
     * Absolute offset of the chunk data from file start.
     */
    long dataOffset;

    /**
     * All chunks have the following format:
     *
     * 4 bytes: an ASCII identifier for this chunk (examples are "fmt " and "data"; note the space in "fmt ").
     * 4 bytes: an unsigned, little-endian 32-bit integer with the length of this chunk (except this field itself and the chunk identifier).
     *  variable-sized field: the chunk data itself, of the size given in the previous field.
     *  a pad byte, if the chunk's length is not even.
     * 
     * @param file Input stream
     * @param startOffset Absolute start offset of this riff chunk.
     */
    RIFFChunk(BytesFile file, long startOffset) {
        this.file = file;

        try {
            this.file.seek(startOffset);
            
            this.tag = StandardCharsets.UTF_8.decode(this.file.read(4)).toString();
            this.size = this.file.read(4).asIntBuffer().get();
            this.dataOffset = this.file.tell();
        }
        catch (IOException ie) {
            // TODO: shouldn't happen??
        }
    }

    /**
     * Skip over the rest of this chunk (useful for enumerating chunks).
     */
    void skipOver() {
        try {
            this.file.seek(this.dataOffset + this.size);
        }
        catch (IOException ie) {
            // TODO: not really sure what you want me to do about it :/
        }
    }

    /**
     * Seek within this chunk's data region.
     * 
     * @param offset Offset within this chunk.
     */
    void seek(int offset) {
        if (offset >= this.size)
            throw new IndexOutOfBoundsException(offset + " >= " + this.size);

        try {
            this.file.seek(this.dataOffset + offset);
        }
        catch (IOException ie) {
            // TODO: not really sure what you want me to do about it :/
        }
    }

    /**
     * Read data within this chunk. If more bytes are requested than are available,
     * only what remains within the chunk will be provided.
     * 
     * @param bytes Number of bytes to read from this chunk.
     * @return The byte data read.
     */
    ByteBuffer read(int bytes) throws IOException {
        int chunkLoc = (int)((this.file.tell() - this.dataOffset) & 0xFFFFFFFF);

        // omg its a bounds check what nooo wayyyy
        if (chunkLoc + bytes >= this.size)
            bytes = this.size - chunkLoc;

        return this.file.read(bytes);
    }

    /**
     * Read data within this chunk into the buffer provided.
     * 
     * @param buffer Buffer to dump samples into.
     * @return The number of bytes read.
     * @throws IOException We have some ISSUES PEOPLE!!!!
     */
    int readinto(ByteBuffer buffer) throws IOException {
        int chunkLoc = (int)((this.file.tell() - this.dataOffset) & 0xFFFFFFFF);
        int bufferLen = buffer.limit();

        // more bounds check
        // its not supposed to be good its supposed to work
        if (chunkLoc + bufferLen >= this.size) {
            bufferLen = this.size - chunkLoc;
            Logger.log("riff", "buffer overrun on read; truncated to " + bufferLen + " B");
        }

        return this.file.readinto(buffer);
    }
}
