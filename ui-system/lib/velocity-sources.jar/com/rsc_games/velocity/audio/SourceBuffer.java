package com.rsc_games.velocity.audio;

import static org.lwjgl.openal.AL10.AL_BUFFER;
import static org.lwjgl.openal.AL10.alBufferData;
import static org.lwjgl.openal.AL10.alSourcei;

import java.io.IOException;
import java.nio.ByteBuffer;

class SourceBuffer {
    private AudioEngine engine;
    private int bufferID;

    private long engineID;

    // TODO: could do better refcount with a weakreference list. Would remove the need
    // for finalizers.
    private int refcount;

    // AudioClips are referenced externally and provide an ID to reference this clip.
    // The entire clip is stored in memory and so should not be used for music tracks.
    SourceBuffer(AudioEngine engine, long engineID, String fileName) {
        this.engine = engine;
        this.engineID = engineID;

        try {
            WaveDecoder wav = new WaveDecoder(fileName);

            // TODO: error checking
            this.bufferID = this.engine.genBuffer();
            int bufSize = wav.frameCount * wav.frameWidth;

            // Only read once and by off heap code so eliminate copies.
            ByteBuffer sampleData = ByteBuffer.allocateDirect(bufSize);
            int format = wav.getSampleFormat();

            alBufferData(bufferID, format, sampleData, wav.frameRate);
        }
        catch (IOException ie) {
            throw new RuntimeException("Failed to load clip " + fileName);
        }
    }

    /**
     * Bind this buffer to a provided source. Sources can share buffers.
     * 
     * @param sourceID Source to register this buffer with.
     */
    void bindToSource(int sourceID) {
        alSourcei(sourceID, AL_BUFFER, this.bufferID);
    }

    /**
     * Get the audio engine buffer ID. This does NOT disclose the openal
     * buffer ID.
     * Only call this when creating a new reference to this buffer. Otherwise
     * will break garbage collection.
     * 
     * @return Engine buffer ID.
     */
    long getNewHandle() {
        refcount++;
        return engineID;
    }

    /**
     * Determine if this buffer has any remaining references.
     * 
     * @return Whether the buffer has references or if it can be GC'd.
     */
    boolean hasReferences() {
        return this.refcount != 0;
    }

    /**
     * Free clip buffers.
     */
    void deallocate() {
        this.engine.delBuffer(this.bufferID);
    }
}
