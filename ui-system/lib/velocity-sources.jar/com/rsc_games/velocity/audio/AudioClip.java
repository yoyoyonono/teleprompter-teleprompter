package com.rsc_games.velocity.audio;

import static org.lwjgl.openal.AL10.AL_GAIN;
import static org.lwjgl.openal.AL10.AL_PITCH;
import static org.lwjgl.openal.AL10.AL_ROLLOFF_FACTOR;
import static org.lwjgl.openal.AL10.alSourcePause;
import static org.lwjgl.openal.AL10.alSourcePlay;
import static org.lwjgl.openal.AL10.alSourceRewind;
import static org.lwjgl.openal.AL10.alSourceStop;
import static org.lwjgl.openal.AL10.alSourcef;

public class AudioClip {
    AudioEngine engine;
    long bufferID;
    int sourceID;

    /**
     * Create a playable audio clip. Memory is shared between clips.
     * 
     * @param path Path to the file on disk.
     * @param spacial Whether the clip should fade depending on distance.
     * @param volume The volume of the clip (from 0-1)
     */
    public AudioClip(String path, boolean spacial, float volume) {
        SourceBuffer buffer = AudioEngine.theEngine.getSourceBuffer(path);
        init(buffer, AudioEngine.theEngine);

        setVolume(volume);

        if (!spacial)
            alSourcef(this.sourceID, AL_ROLLOFF_FACTOR, 0f);
    }

    /**
     * Create a playable audio clip. Memory is shared between clips. Volume is
     * set to a default maximum of 1.0
     * 
     * @param path Path to the file on disk.
     * @param spacial Whether the clip should fade depending on distance.
     */
    public AudioClip(String path, boolean spacial) {
        this(path, spacial, 1f);
    }

    /**
     * Create a playable audio clip. Memory is shared between clips. Clip
     * is assumed to be spacial.
     * 
     * @param path Path to the file on disk.
     * @param volume The volume of the clip (from 0-1)
     */
    public AudioClip(String path, float volume) {
        this(path, true, volume);
    }

    /**
     * Create a playable audio clip. Memory is shared between clips. Clip
     * is assumed to be spacial and volume is 1.0
     * 
     * @param path Path to the file on disk.
     */
    public AudioClip(String path) {
        this(path, true, 1f);
    }

    /**
     * Initialize and load all required resources for this audio clip.
     * 
     * @param buffer Clip buffer to use.
     * @param engine Audio engine.
     */
    private void init(SourceBuffer buffer, AudioEngine engine) {
        this.engine = engine;
        this.bufferID = buffer.getNewHandle();
        this.sourceID = engine.genSource();

        buffer.bindToSource(this.sourceID);
    }

    public void play() {
        alSourcePlay(this.sourceID);
    }

    public void pause() {
        alSourcePause(this.sourceID);
    }

    public void stop() {
        alSourceStop(this.sourceID);
    }

    public void reset() {
        alSourceRewind(this.sourceID);
    }

    public void setVolume(float volume) {
        alSourcef(this.sourceID, AL_GAIN, volume);
    }

    public void setPitch(float pitch) {
        alSourcef(this.sourceID, AL_PITCH, pitch);
    }

    // TODO: stuff like rolloff factors etc
    // TODO: position support.
    // see https://www.openal.org/documentation/OpenAL_Programmers_Guide.pdf
}
